from NeuralNetwork import Network
import numpy as np

class NeuralNetHolder:

    def __init__(self):
        super().__init__()
        
        self.nn = Network([2,4,2])

        # initialize the weights
        self.nn.initializeWeights()

        # Load minimum and maximum value
        self.nn.loadMinMax()
    
    def predict(self, input_row):
        input = input_row.split(",")
        input = [float(input[0]), float(input[1])]

        # normalize the inputs
        normalizedInput = self.nn.normalize(input)
        print("normalizedInput: ",normalizedInput)
        
        # Set the input of the network 
        self.nn.setInput(normalizedInput)
        self.nn.feedForword()

        # Predicted results from the trained model
        predicted_Results = self.nn.getResults()
        print("predicted Results: ", predicted_Results)
        
        # denormalize the outputs
        denormalizedPredictedResults = self.nn.denormalize(predicted_Results)
        print("Denormalized Predicted Results :",denormalizedPredictedResults)
        return denormalizedPredictedResults