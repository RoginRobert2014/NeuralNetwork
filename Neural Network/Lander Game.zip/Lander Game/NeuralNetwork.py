import math
import random
import ast
import pickle

class Connection:
    def __init__(self, connectedNeuron):
        self.connectedNeuron=connectedNeuron
        #weight of the connection
        self.weight = random.uniform(-1,1) 
        #delta weight for momentum
        self.dWeight=0.0 
    

    # overwride of string method of object class
    def __str__(self):
        return str(self.__dict__)

# The Neuron class.........................../////////////        
class Neuron:
    # Learning rate
    eta=0.6
    #momentum factor of the neurons
    alpha=0.1

    def __init__(self,layer):
        # Can store multiple Neurons
        self.dendrons=[] 
        # Error from Activation function
        self.error=0.0
        self.gradient=0.0
        self.output=0.0
        if layer is None:
            pass
        else:
            for neuron in layer:
                con=Connection(neuron)
                self.dendrons.append(con)
    
    #Accumulate error sent from all the neurons in the next layer during backpropagation
    def addError(self, err):
        self.error = self.error + err

    #Sigmoid is our activation function        
    def sigmoid(self, x):
        return 1 / (1 + math.exp(-x * 0.65))
    
    #Derivative of the sigmoid function
    #It will be used to calculate the gradient of the neuron during backpropagation
    def dSigmoid(self, x):
        return .65 * float(x) * (1.0 - float(x))
    
    def setError(self, err):
        self.error = err

    def setOutput(self, output):
        self.output=output

    def getOutput(self):
        return self.output
    
    #  Feedforward for a single neuron
    def feedForword(self):
        sumOutput=0 # 0.0
        if(len(self.dendrons)==0):
            return
        for dendron in self.dendrons:       
            sumOutput=sumOutput + float(dendron.connectedNeuron.getOutput())*dendron.weight
        self.output=self.sigmoid(sumOutput)

    # Back Propagation method for a single neuron
    def backPropagate(self):
        self.gradient = self.error * self.dSigmoid(self.output)
        for dendron in self.dendrons:
            dendron.dWeight = Neuron.eta * (float(dendron.connectedNeuron.output)*self.gradient) + self.alpha * dendron.dWeight
            dendron.weight = dendron.weight + dendron.dWeight
            dendron.connectedNeuron.addError(dendron.weight * self.gradient)
        self.error = 0    

    # Dendron details
    def __str__(self):
        dendronDetails = ''
        for d in self.dendrons:
            dendronDetails += str(d.__dict__) + "\n"
        return dendronDetails
       
# The Network class.........................../////////////
class Network:
    def __init__(self,topology):
        #topology is the number of nuerons in each layer 
        self.topology = topology
        #Layer
        self.layers=[]
        self.min = []
        self.max = []        
        for numNeuron in topology:
            layer=[]
            for i in range(numNeuron):
                if(len(self.layers)==0):
                    layer.append(Neuron(None))
                else:
                    layer.append(Neuron(self.layers[-1]))
            # add bias neuron
            layer.append(Neuron(None)) 
            # setting output of bias neuron as 1
            layer[-1].setOutput(1)
            self.layers.append(layer)

    # Sets inputs in regular neurons: X postion, Y Position from training data
    def setInput(self, inputs):
        for i in range(len(inputs)):
            self.layers[0][i].output=inputs[i]

    # FeedForword the network
    def feedForword(self):
        for layer in self.layers[1:]:
            for neuron in layer:
                neuron.feedForword()

    # Back Propagate The Network
    def backPropagate(self,target):
        for i in range(len(target)):
            self.layers[-1][i].setError(float(target[i])-float(self.layers[-1][i].getOutput()))
        for layer in self.layers[::-1]: #reverse order 
            for neuron in layer:
                neuron.backPropagate()

    # Calculating overall error of the network
    def getError(self,target):
        err=0
        for i in range(len(target)):
            e=(float(target[i])-self.layers[-1][i].getOutput())
            err = err + e ** 2
        err = err/len(target)
        err=math.sqrt(err)
        return err

    # Get Results from the network-Predict the results
    def getResults(self):
        output=[]
        # Read output values from Last layer except from the bias neuron
        for neuron in self.layers[-1]:
            output.append(neuron.getOutput())
        # removing the bias neuron
        output.pop()        
        return output

    #Save the weights in a file
    def saveWeights(self):
        weights = []
        for layer in self.layers[1:]:
            for n in layer:
                w = []
                for dendron in n.dendrons:
                    w.append(dendron.weight)
                weights.append(w)
        with open('weight_data.txt', 'w') as f:
            f.write(str(weights))
           
    # Initialize the weights
    def initializeWeights(self):
        weights = []
        with open('weight_data.txt', 'r') as f:
            allLines = f.readlines()
            weights= allLines[0]
            weights = ast.literal_eval(weights)            

        i = 0
        j = 0
        for layer in self.layers[1:]:
            for dendron in layer:
                for indexDendron in range(len(dendron.dendrons)):
                    if len(weights[i]) != 0:
                        dendron.dendrons[indexDendron].weight = weights[i][j]
                        j += 1 
                i += 1
                j= 0                       

    # Save mimimum and maximum values of the data set in a file
    def loadMinMax(self):
        w = None
        with open('min_max_data.data', 'rb') as f:
            w = pickle.load(f)
            self.min = w[0]
            self.max = w[1]   
        pass

    # Normalize the data 
    def normalize(self, sample_input):
        normalized_X_Value = (float(sample_input[0]) - self.min[0])/(self.max[0]-self.min[0])
        normalized_Y_Value = (float(sample_input[1]) - self.min[1])/(self.max[1]-self.min[1])
        normalizedValue = [normalized_X_Value, normalized_Y_Value]
        return normalizedValue

    # Denormalize the data
    def denormalize(self, sample_input):
        denormalized_X_Velocity = (float(sample_input[0]) * (self.max[2]-self.min[2]) + self.min[2])
        denormalized_Y_Velocity = (float(sample_input[1]) * (self.max[3]-self.min[3]) + self.min[3])
        denormalizedValue = [denormalized_X_Velocity, denormalized_Y_Velocity]
        return denormalizedValue

    # Layer details
    def __str__(self):
        layerDetails = ''
        for indexLayer, layer in enumerate(self.layers):
            layerDetails += "layer "+ str(indexLayer)+ " neurons\n"
            for n in layer:
                layerDetails += str(n)+"\n"
        return layerDetails

# Training and Testing the network ...........................//////////////////
def main():
    topology=[2,4,2]
    net=Network(topology)
    inputs = []
    outputs=[]

    traininginputData = open("Training_Data.csv", "r")
    for singleLine in traininginputData:
        inputValues = singleLine.rstrip().split(",")[:2]
        outputValues = singleLine.rstrip().split(",")[2:]
        inputs.append(inputValues)
        outputs.append(outputValues)
    
    # Train the network ................//////////
    # Number of Epochs
    numberOfEpoch = 1000
    for t in range(numberOfEpoch):
        err = 0
        for i in range(len(inputs)):
            #Set the input X Velocity and Y velocity
            net.setInput(inputs[i])
            net.feedForword()
            net.backPropagate(outputs[i])
            err = err + net.getError(outputs[i])
        print( "Epoch {}, RMSE:{} ".format(t, math.sqrt(err/len(inputs))))


    # Testing the network...................///////////
    inputs = []
    outputs=[]

    #testing with RMSE validation set
    testingInputData = open("Testing_Data.csv", "r")
    for singleLine in testingInputData:
        inputValues = singleLine.rstrip().split(",")[:2]
        outputValues = singleLine.rstrip().split(",")[2:]
        inputs.append(inputValues)
        outputs.append(outputValues)

    #testing with 10 validation set
    x = inputs[-10:]
    y = outputs[-10:]

    # Save the training weights
    net.saveWeights()

    # initialize the weights
    net.initializeWeights()

    print("Testing the last 10 rows - ")
    for idx, x_i in enumerate(x):
        net.setInput(x_i)
        net.feedForword()
        print("Input: ", x_i)
        print("Actual: ",y[idx])
        print("Predicted: ",net.getResults())
        
    # Load minimum and maximum value
    net.loadMinMax()
    x_Input = inputs[-1:]

    # normalize the inputs
    normalizedInput = net.normalize(x_Input[0])

    # Set the input in the network
    net.setInput(normalizedInput)

    # Predicted results from the trained model
    predictedResults = net.getResults()
    print("Predicted Results: " + str(predictedResults))

    # denormalize the outputs
    denormalizedPredictedResults = net.denormalize(predictedResults)
    print("Denormalized Predicted Results: " + str(denormalizedPredictedResults)) 
    
if __name__=='__main__':
    main()