import pandas as pd
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
import pickle

print("Data preprocessing Started............")

#Read data from lander game out put excel file
inputData = pd.read_csv("ce889_dataCollection.csv", usecols=[0,1]) 
outputData = pd.read_csv("ce889_dataCollection.csv", usecols=[2,3]) 

# Split the data into Train and Test
x_train,x_test, y_train, y_test = train_test_split(inputData,outputData)

# Normalising training and testing data
min_max_scaler = preprocessing.MinMaxScaler()

# Normalising the training data
training_Data = x_train.join(y_train)
training_Data_scaled = min_max_scaler.fit_transform(training_Data)
training_Data_df = pd.DataFrame(training_Data_scaled)
training_Data_df.to_csv('Training_Data.csv', index=False, header=None)

# Save min and max values
max_Values = min_max_scaler.data_max_
min_Values = min_max_scaler.data_min_
min_maxData = [min_Values.tolist(),max_Values.tolist()]
with open('min_max_data.data', 'wb') as f:
    w = pickle.dump(min_maxData, f)

# for debugging -- Start
with open('min_max_data.txt', 'w') as D:
            D.write(str(min_maxData))
# for debugging -- End            

# Normalising the test data
test_Data = x_test.join(y_test)
test_Data_scaled = min_max_scaler.fit_transform(test_Data)
test_Data_df = pd.DataFrame(test_Data_scaled)
test_Data_df.to_csv('Testing_Data.csv', index=False, header=None)

print("Data preprocessing completed............")
